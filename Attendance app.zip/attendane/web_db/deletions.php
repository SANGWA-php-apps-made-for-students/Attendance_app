<?php 
require_once 'connection.php';
class deletions{


 function deleteFrom_account( $account_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM account where account_id =:account_id");
$smt->bindValue(':account_id',$account_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_account_category( $account_category_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM account_category where account_category_id =:account_category_id");
$smt->bindValue(':account_category_id',$account_category_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_profile( $profile_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM profile where profile_id =:profile_id");
$smt->bindValue(':profile_id',$profile_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_attendance( $attendance_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM attendance where attendance_id =:attendance_id");
$smt->bindValue(':attendance_id',$attendance_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


}

