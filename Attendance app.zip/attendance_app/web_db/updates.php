<?php

require_once 'connection.php';
class updates{

 function update_account( $account_category, $date_created, $profile, $username, $password, $is_online,$account_id){
		$database = new dbconnection();
		$db=$database->openconnection();
		$stmt=$db->prepare("UPDATE account set 
		account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
		$stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online ,$account_id ));

}
 function update_account_category( $name,$account_category_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
$stmt->execute(array($name ,$account_category_id ));

}
 function update_profile( $dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image,$profile_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
$stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image ,$profile_id ));

}
 function update_attendance( $attendance, $entry_date, $User, $account,$attendance_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE attendance set 
attendance= ?, entry_date= ?, User= ?, account= ? WHERE attendance_id=?");
$stmt->execute(array($attendance, $entry_date, $User, $account ,$attendance_id ));

}

}

