<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_account($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account </td>
                    <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_id']; ?>
                    </td>
                    <td class="account_category_id_cols account " title="account" >
                        <?php echo $this->_e($row['account_category']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date_created']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['profile']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['username']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['password']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['is_online']); ?>
                    </td>


                    <td>
                        <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="account_id"  data-table="
                           <?php echo $row['account_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_update_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_account_category($id) {

            $db = new dbconnection();
            $sql = "select   account.account_category from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account_category'];
            echo $field;
        }

        function get_chosen_account_date_created($id) {

            $db = new dbconnection();
            $sql = "select   account.date_created from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date_created'];
            echo $field;
        }

        function get_chosen_account_profile($id) {

            $db = new dbconnection();
            $sql = "select   account.profile from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['profile'];
            echo $field;
        }

        function get_chosen_account_username($id) {

            $db = new dbconnection();
            $sql = "select   account.username from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['username'];
            echo $field;
        }

        function get_chosen_account_password($id) {

            $db = new dbconnection();
            $sql = "select   account.password from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['password'];
            echo $field;
        }

        function get_chosen_account_is_online($id) {

            $db = new dbconnection();
            $sql = "select   account.is_online from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['is_online'];
            echo $field;
        }

        function All_account() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_id   from account";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function get_last_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function list_account_category($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account_category";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account_category </td>
                    <td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_category_id']; ?>
                    </td>
                    <td class="name_id_cols account_category " title="account_category" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="account_category_id"  data-table="
                           <?php echo $row['account_category_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_category_update_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_category_name($id) {

            $db = new dbconnection();
            $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_category_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_account_category() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_category_id   from account_category";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_account_by_profile($profile) {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "SELECT * FROM faradg_attendance.account
                            join profile on profile.profile_id=account.profile
                            where account.account_id=:acc";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":acc" => $profile));
            while ($row = $stmt->fetch()) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function get_last_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function list_profile($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from profile";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> profile </td>
                    <td> Date of birth </td>
                    <td> name </td>
                    <td> last name </td>
                    <td>Gender  </td>
                    <td> Telephone </td>
                    <td> Email </td>
                    <td> Residence </td>
                    <td> Image </td>

                    <td>Delete</td><td>Update</td>
                </tr>
            </thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['profile_id']; ?>
                    </td>
                    <td class="dob_id_cols profile " title="profile" >
                        <?php echo $this->_e($row['dob']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['gender']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['telephone_number']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['email']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['residence']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['image']); ?>
                    </td>


                    <td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="profile_id"  data-table="
                           <?php echo $row['profile_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="profile_update_link" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

        function list_profile_to_attend() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from profile "
                    . "join account on account.profile=profile.profile_id ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> <input id="check_all" type="checkbox" /> </td>
                    <td> profile </td>
                    <td> name </td>
                    <td> last name </td>
                    <td>  </td>
                    <td>  </td>
                    <td>  </td>
                    <td>  </td>
                    <td>  </td>
                    <td>  </td>
                    <td class="off">Delete</td><td class="off">Update</td>
                </tr>
            </thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 
                    <td>
                        <input type="checkbox" name="accountid[]" value="<?php echo $row['account_id']; ?>" class="checkables" />
                    </td>
                    <td>
                        <?php echo $row['profile_id']; ?>
                    </td>
                    <td class="dob_id_cols profile " title="profile" >
                        <?php echo $this->_e($row['dob']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['gender']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['telephone_number']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['email']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['residence']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['image']); ?>
                    </td>
                    <td class="off">
                        <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="profile_id"  data-table="
                           <?php echo $row['profile_id']; ?>">Delete</a>
                    </td>
                    <td class="off">
                        <a href="#" class="profile_update_link" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?>                    <tr><td colspan="12"> <input type="submit" class="confirm_buttons"style="float: right;" name="send_attendance" value="Save"/>  </td></tr>
        </table>
        <?php
    }

//chosen individual field
    function get_chosen_profile_dob($id) {

        $db = new dbconnection();
        $sql = "select   profile.dob from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['dob'];
        echo $field;
    }

    function get_chosen_profile_name($id) {

        $db = new dbconnection();
        $sql = "select   profile.name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

    function get_chosen_profile_last_name($id) {

        $db = new dbconnection();
        $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['last_name'];
        echo $field;
    }

    function get_chosen_profile_gender($id) {

        $db = new dbconnection();
        $sql = "select   profile.gender from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['gender'];
        echo $field;
    }

    function get_chosen_profile_telephone_number($id) {

        $db = new dbconnection();
        $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['telephone_number'];
        echo $field;
    }

    function get_chosen_profile_email($id) {

        $db = new dbconnection();
        $sql = "select   profile.email from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['email'];
        echo $field;
    }

    function get_chosen_profile_residence($id) {

        $db = new dbconnection();
        $sql = "select   profile.residence from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['residence'];
        echo $field;
    }

    function get_chosen_profile_image($id) {

        $db = new dbconnection();
        $sql = "select   profile.image from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['image'];
        echo $field;
    }

    function All_profile() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  profile_id   from profile";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function get_first_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }

    function get_last_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }

    function list_attendance($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from attendance "
                . " join account on account.account_id=attendance.account "
                . "join profile on profile.profile_id=account.profile";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> attendance </td>
                    <td> Status </td>
                    <td> Class </td>
                    <td> Section </td>
                    <td> Entry Date </td>
                    <td> User </td><td> Student </td>
                    <td class="off">Delete</td><td class="off">Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['attendance_id']; ?>
                    </td>
                    <td class="attendance_id_cols attendance " title="attendance" >
                        <?php echo $this->_e($row['attendance']); ?>
                    </td>
                    <td class="attendance_id_cols attendance " title="attendance" >
                        <?php echo $this->_e($row['class']); ?>
                    </td>
                    <td class="attendance_id_cols attendance " title="attendance" >
                        <?php echo $this->_e($row['section']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['User']); ?>
                    </td>
                    <td>
                        <?php
                        echo $this->_e($row['name']) . ' ';
                        echo $this->_e($row['last_name']);
                        ?>
                    </td>


                    <td class="off">
                        <a href="#" class="attendance_delete_link" style="color: #000080;" data-id_delete="attendance_id"  data-table="
                           <?php echo $row['attendance_id']; ?>">Delete</a>
                    </td>
                    <td class="off">
                        <a href="#" class="attendance_update_link" style="color: #000080;" value="
                           <?php echo $row['attendance_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

        function list_attendance_absent() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from attendance "
                    . "right join account on account.account_id=attendance.account "
                    . " join profile on profile.profile_id=account.profile "
                    . "  where  attendance.attendance_id is null";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> attendance </td>
                    <td> Status </td>
                    <td> Class </td>
                    <td> Section </td>
                    <td> Entry Date </td>
                    <td> User </td>
                    <td> Student </td>

                    <td class="off">Delete</td><td class="off">Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        --
                    </td>
                    <td class="attendance_id_cols attendance " title="attendance" >
                        Absent
                    </td>
                    <td class="attendance_id_cols attendance " title="attendance" >
                        <?php echo $this->_e($row['class']); ?>
                    </td>
                    <td class="attendance_id_cols attendance " title="attendance" >
                        <?php echo $this->_e($row['section']); ?>
                    </td>

                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['User']); ?>
                    </td>
                    <td>
                        <?php
                        echo $this->_e($row['name']) . ' ';
                        echo $this->_e($row['last_name']);
                        ?>
                    </td>


                    <td class="off">
                        <a href="#" class="attendance_delete_link" style="color: #000080;" data-id_delete="attendance_id"  data-table="
                           <?php echo $row['attendance_id']; ?>">Delete</a>
                    </td>
                    <td class="off">
                        <a href="#" class="attendance_update_link" style="color: #000080;" value="
                           <?php echo $row['attendance_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_attendance_attendance($id) {

            $db = new dbconnection();
            $sql = "select   attendance.attendance from attendance where attendance_id=:attendance_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':attendance_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['attendance'];
            echo $field;
        }

        function get_chosen_attendance_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   attendance.entry_date from attendance where attendance_id=:attendance_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':attendance_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_attendance_User($id) {

            $db = new dbconnection();
            $sql = "select   attendance.User from attendance where attendance_id=:attendance_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':attendance_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function get_chosen_attendance_account($id) {

            $db = new dbconnection();
            $sql = "select   attendance.account from attendance where attendance_id=:attendance_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':attendance_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function All_attendance() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  attendance_id   from attendance";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_attendance() {
            $con = new dbconnection();
            $sql = "select attendance.attendance_id from attendance
                    order by attendance.attendance_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['attendance_id'];
            return $first_rec;
        }

        function get_last_attendance() {
            $con = new dbconnection();
            $sql = "select attendance.attendance_id from attendance
                    order by attendance.attendance_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['attendance_id'];
            return $first_rec;
        }

        function get_account_category_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select account_category.account_category_id,   account_category.name from account_category";
            ?>
            <select class="textbox cbo_account_category"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
        <?php
    }

    function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_image_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
        </select>
        <?php
    }

    function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }

}
