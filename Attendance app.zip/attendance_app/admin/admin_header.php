<div class="parts  eighty_centered my_title">        
    <div class="parts  no_paddin_shade_no_Border xxx_titles "><center>
            ESIR STUDENT ONLINE ATTENDANCE</center>
    </div>
</div> 
<div class="parts menu eighty_centered">

    <a href="new_profile.php">Student</a>
    <a href="new_attendance.php">Attendance</a>

    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border off">
        <a href="login.php">Login</a>
    </div>
</div>
